﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ELEKTRONIK
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int row = 0;
            dataGridView1.Rows.Add();
            row = dataGridView1.Rows.Count - 2;
            dataGridView1["Column1", row].Value = dataGridView1.RowCount - 1;
            dataGridView1["Column2", row].Value = textBox1.Text;
            dataGridView1["Column3", row].Value = textBox2.Text;
            dataGridView1["Column4", row].Value = comboBox1.Text;
            dataGridView1["Column5", row].Value = textBox3.Text;
            dataGridView1["Column6", row].Value = textBox4.Text;
            dataGridView1.Refresh();
            MessageBox.Show("Data berhasil disimpan!");
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            comboBox1.Text = string.Empty;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.RemoveAt(this.dataGridView1.SelectedRows[0].Index);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }
    }
}
